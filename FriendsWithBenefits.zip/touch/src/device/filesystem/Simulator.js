/**
 * @private
 */
Ext.define('Ext.device.filesystem.Simulator', {
    extend: 'Ext.device.filesystem.HTML5'
});