/**
 * @private
 */
Ext.define('Ext.device.device.Simulator', {
    extend: 'Ext.device.device.Abstract'
});
